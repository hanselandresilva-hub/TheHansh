# 🚀 GUÍA COMPLETA DE DEPLOY EN VERCEL

## ⚡ MÉTODO 1: DRAG & DROP (MÁS FÁCIL - 2 MINUTOS)

### Paso 1: Ir a Vercel
1. Abre tu navegador
2. Ve a: **https://vercel.com**
3. Click en **"Sign Up"** (esquina superior derecha)
4. Elige registrarte con:
   - GitHub (recomendado si tienes cuenta)
   - GitLab
   - Bitbucket
   - Email

### Paso 2: Crear Nuevo Proyecto
1. Una vez dentro, verás tu dashboard
2. Click en el botón **"Add New..."**
3. Selecciona **"Project"**

### Paso 3: Subir tu Código
**Opción A - Drag & Drop:**
1. En la pantalla, verás una zona que dice "Drop your project files here"
2. Arrastra TODA la carpeta `flippay-vercel`
3. O click en "Browse" y selecciona los archivos:
   - index.html
   - vercel.json
   - package.json
   - README.md

**Opción B - Conectar GitHub:**
1. Click en "Import Git Repository"
2. Conecta tu cuenta de GitHub
3. Selecciona el repositorio
4. Vercel detectará todo automáticamente

### Paso 4: Configurar Deploy
1. **Project Name**: Pon `flippay` o `flippay-perfumeria`
2. **Framework Preset**: Deja en "Other" o "Static Site"
3. **Root Directory**: Deja en blanco (raíz del proyecto)
4. **Build Command**: Deja vacío
5. **Output Directory**: Deja vacío (no es necesario)

### Paso 5: Deploy
1. Click en el botón grande azul **"Deploy"**
2. Vercel empezará a desplegar
3. Verás una barra de progreso con estas etapas:
   - ✓ Building
   - ✓ Deploying
   - ✓ Ready

### Paso 6: ¡LISTO! 🎉
1. Cuando termine, verás: **"Congratulations! 🎉"**
2. Tu URL será algo como: `https://flippay-abc123.vercel.app`
3. Click en **"Visit"** para ver tu sitio online

---

## 🌐 MÉTODO 2: VERCEL CLI (Para Desarrolladores)

### Paso 1: Instalar Vercel CLI
Abre tu terminal y ejecuta:

```bash
# Windows (con npm)
npm install -g vercel

# Mac/Linux (con npm)
npm install -g vercel

# O con yarn
yarn global add vercel
```

### Paso 2: Navegar a tu Proyecto
```bash
cd ruta/a/flippay-vercel
```

### Paso 3: Login en Vercel
```bash
vercel login
```
- Te pedirá email
- Recibirás un código de verificación
- Ingresa el código

### Paso 4: Deploy
```bash
# Deploy a preview
vercel

# O deploy directo a producción
vercel --prod
```

### Paso 5: Ver tu Sitio
Vercel te dará 2 URLs:
- **Preview**: `https://flippay-abc123.vercel.app`
- **Production**: `https://flippay.vercel.app`

---

## 🔗 CONECTAR TU DOMINIO PROPIO

### Opción A: Dominio GRATIS (Freenom)

#### Paso 1: Obtener Dominio Gratis
1. Ve a: **https://www.freenom.com**
2. Busca tu dominio: `flippay.tk` o `flippay.ml`
3. Click "Get it now!"
4. Click "Checkout"
5. Selecciona "12 Months @ FREE"
6. Completa registro (usa tu email real)
7. Confirma tu email

#### Paso 2: Agregar en Vercel
1. En tu proyecto de Vercel, ve a **"Settings"**
2. Click en **"Domains"** en el menú lateral
3. Ingresa tu dominio: `flippay.tk`
4. Click **"Add"**

#### Paso 3: Configurar DNS en Freenom
Vercel te mostrará algo como:

```
Type: A Record
Name: @
Value: 76.76.21.21

Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

Ahora ve a Freenom:
1. Login en Freenom
2. "Services" → "My Domains"
3. Click "Manage Domain" en tu dominio
4. "Management Tools" → "Nameservers"
5. Selecciona "Use custom nameservers"
6. Ingresa:
   ```
   ns1.vercel-dns.com
   ns2.vercel-dns.com
   ```
7. Click "Change Nameservers"

#### Paso 4: Esperar
- Propagación DNS: 5-30 minutos
- Vercel activará SSL gratis automáticamente
- ¡Tu sitio estará en `https://flippay.tk`!

---

### Opción B: Dominio Pagado $0.99 (Namecheap)

#### Paso 1: Comprar Dominio
1. Ve a: **https://www.namecheap.com**
2. Busca: `flippay.xyz` o `flippay.online`
3. Agrega al carrito (debe costar $0.99-$1.99 primer año)
4. Completa la compra

#### Paso 2: Agregar en Vercel
1. En tu proyecto Vercel → "Settings" → "Domains"
2. Ingresa: `flippay.xyz`
3. Click "Add"

#### Paso 3: Configurar en Namecheap
1. Login en Namecheap
2. "Domain List" → Click en tu dominio
3. Tab "Advanced DNS"
4. Agrega estos records:

```
Type: A Record
Host: @
Value: 76.76.21.21
TTL: Automatic

Type: CNAME Record
Host: www
Value: cname.vercel-dns.com
TTL: Automatic
```

O más fácil:
1. Scroll a "NAMESERVERS"
2. Selecciona "Custom DNS"
3. Ingresa:
   ```
   ns1.vercel-dns.com
   ns2.vercel-dns.com
   ```
4. Click guardar

#### Paso 4: ¡Listo!
- Espera 5-30 minutos
- SSL gratis se activa solo
- Tu sitio: `https://flippay.xyz`

---

## 🔍 VERIFICAR QUE TODO FUNCIONA

### Checklist:
- [ ] Sitio carga correctamente
- [ ] Todas las secciones visibles
- [ ] Botones funcionan
- [ ] Countdown timer corre
- [ ] Notificaciones de social proof aparecen
- [ ] Hover effects en productos
- [ ] Navigation smooth scroll funciona
- [ ] Sticky cart aparece al scroll
- [ ] Modal de wallet funciona

### Ver en Diferentes Dispositivos:
1. En Chrome: Click derecho → "Inspect" → Toggle device toolbar
2. Prueba en:
   - iPhone (mobile)
   - iPad (tablet)
   - Desktop

---

## ⚙️ CONFIGURACIONES AVANZADAS (Opcional)

### 1. Analytics (Google Analytics)
Agrega antes de `</head>` en index.html:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### 2. Favicon Personalizado
1. Crea tu logo en formato .ico o .png
2. Súbelo a Vercel
3. Agrega en `<head>`:
```html
<link rel="icon" type="image/png" href="/favicon.png">
```

### 3. Redirecciones
Agrega en `vercel.json`:
```json
"redirects": [
  {
    "source": "/viejo-link",
    "destination": "/nuevo-link",
    "permanent": true
  }
]
```

### 4. Variables de Entorno
1. En Vercel Dashboard → "Settings" → "Environment Variables"
2. Agrega tus API keys
3. Usa en tu código con `process.env.MI_VARIABLE`

---

## 🆘 SOLUCIÓN DE PROBLEMAS

### Error: "Build Failed"
✅ Solución: 
- Verifica que `index.html` esté en la raíz
- Revisa que `vercel.json` esté presente
- Chequea la consola por errores de sintaxis

### Error: "Domain Not Found"
✅ Solución:
- Espera 30 minutos más (propagación DNS)
- Verifica los nameservers en tu proveedor
- Limpia cache DNS: `ipconfig /flushdns` (Windows) o `sudo dscacheutil -flushcache` (Mac)

### Sitio se ve roto en mobile
✅ Solución:
- Abre Chrome DevTools
- Toggle responsive mode
- Verifica media queries en CSS

### SSL no activa
✅ Solución:
- Espera 10-30 minutos
- Vercel activa SSL automáticamente
- Si persiste, ve a Settings → Domains → Force HTTPS

---

## 📞 SOPORTE

### Recursos Oficiales:
- 📚 Docs Vercel: https://vercel.com/docs
- 💬 Discord Vercel: https://vercel.com/discord
- 🐦 Twitter: @vercel

### Comunidad:
- Stack Overflow (tag: vercel)
- GitHub Discussions

---

## ✅ CHECKLIST FINAL DE DEPLOY

- [ ] Código subido a Vercel
- [ ] Deploy exitoso (verde ✓)
- [ ] Sitio abre en URL de Vercel
- [ ] Dominio propio configurado (opcional)
- [ ] SSL activado (candado verde en navegador)
- [ ] Probado en mobile y desktop
- [ ] Analytics configurado (opcional)
- [ ] Todo funciona correctamente

---

## 🎉 ¡FELICIDADES!

Tu sitio FLIPPAY está online y listo para:
- Recibir visitantes
- Procesar ventas
- Aceptar pagos con FLIP Token
- Crecer tu negocio de perfumería online

**Próximos pasos sugeridos:**
1. Compartir tu URL en redes sociales
2. Configurar Google Analytics
3. Crear cuentas de redes sociales de FLIPPAY
4. Empezar marketing digital
5. Integrar pasarelas de pago reales
6. Construir base de datos de productos

---

**¿Necesitas ayuda?** ¡No dudes en preguntar!

🚀 **FLIPPAY** - La mejor perfumería online del mundo
