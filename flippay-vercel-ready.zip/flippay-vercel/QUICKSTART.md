# ⚡ GUÍA RÁPIDA - DEPLOY EN 5 MINUTOS

## 🎯 OPCIÓN 1: MÁS RÁPIDA (Sin Código)

### 1️⃣ Descargar
- Descarga el archivo `flippay-vercel-ready.zip`
- Descomprímelo en tu computadora

### 2️⃣ Ir a Vercel
```
🌐 Abre: https://vercel.com
📝 Click: "Sign Up" (usa GitHub o email)
```

### 3️⃣ Crear Proyecto
```
➕ Click: "Add New..." → "Project"
📁 Arrastra la carpeta "flippay-vercel" completa
   O click "Browse" y selecciona los archivos
```

### 4️⃣ Configurar (automático)
```
✅ Project Name: flippay (o el que quieras)
✅ Framework: Other (detectado automáticamente)
✅ Root Directory: ./ (raíz)
✅ Build Command: (dejar vacío)
✅ Output Directory: (dejar vacío)
```

### 5️⃣ Deploy
```
🚀 Click: el botón azul "Deploy"
⏱️ Espera: 30-60 segundos
🎉 ¡LISTO!
```

**Tu sitio estará en:**
```
https://flippay-[random].vercel.app
```

---

## 🌐 OPCIÓN 2: Con Tu Dominio ($0.99)

### Paso 1: Compra Dominio
```
🛒 Ve a: namecheap.com
🔍 Busca: flippay.xyz
💰 Compra: $0.99 (primer año)
```

### Paso 2: Deploy (igual que Opción 1)

### Paso 3: Conectar Dominio
En Vercel:
```
⚙️ Settings → Domains
➕ Add: flippay.xyz
📋 Copia los nameservers que te da Vercel
```

En Namecheap:
```
🌐 Domain List → tu dominio
⚙️ Manage → Advanced DNS
📝 Nameservers → Custom DNS
✏️ Pega:
   ns1.vercel-dns.com
   ns2.vercel-dns.com
💾 Save
```

Espera 10-30 minutos → ¡Listo!
```
https://flippay.xyz 🎉
```

---

## 🆓 OPCIÓN 3: Dominio GRATIS

### Paso 1: Dominio Gratis
```
🌐 Ve a: freenom.com
🔍 Busca: flippay.tk
✅ Get it now!
📅 Period: 12 Months @ FREE
📧 Registra con tu email real
```

### Paso 2: Deploy en Vercel (igual)

### Paso 3: Conectar
En Freenom:
```
⚙️ Services → My Domains → Manage Domain
🌐 Management Tools → Nameservers
✏️ Use custom nameservers:
   ns1.vercel-dns.com
   ns2.vercel-dns.com
💾 Change Nameservers
```

---

## 📱 URLs Finales Posibles

Después del deploy tendrás:

**Sin dominio propio:**
```
✅ Preview: https://flippay-abc123.vercel.app
✅ Production: https://flippay.vercel.app
```

**Con dominio gratis (.tk):**
```
✅ https://flippay.tk
✅ https://www.flippay.tk
```

**Con dominio pagado (.xyz):**
```
✅ https://flippay.xyz
✅ https://www.flippay.xyz
```

**Todos incluyen SSL gratis (candado 🔒)**

---

## ✅ Checklist Post-Deploy

Una vez online, verifica:

- [ ] Sitio carga rápido (< 3 segundos)
- [ ] Logo FLIPPAY visible
- [ ] Colores azules correctos
- [ ] Countdown timer funciona
- [ ] Productos se ven bien
- [ ] Botones responden
- [ ] Notificaciones aparecen
- [ ] Mobile responsive funciona
- [ ] SSL activado (https://)

---

## 🚨 Si Algo Sale Mal

### Error al subir
✅ Verifica que subes la carpeta completa
✅ Debe incluir: index.html, vercel.json, package.json

### No se ve bien
✅ Limpia caché del navegador (Ctrl + Shift + R)
✅ Prueba en modo incógnito

### Dominio no conecta
✅ Espera 30 minutos (propagación DNS)
✅ Verifica los nameservers en tu proveedor
✅ Usa https:// (no http://)

---

## 📞 Ayuda Extra

**Documentación Vercel:**
https://vercel.com/docs

**Video Tutorial (YouTube):**
Busca: "deploy website vercel"

**Soporte Vercel:**
https://vercel.com/support

---

## 🎉 ¡Eso es Todo!

Tu perfumería FLIPPAY estará online en menos de 5 minutos.

**Características que funcionarán:**
✅ Diseño responsive
✅ Countdown timers
✅ Social proof notifications
✅ Sticky cart
✅ Animaciones suaves
✅ Botones interactivos
✅ Modal de wallet crypto

**Lo que necesitarás agregar después:**
⏳ Pasarela de pago real (Stripe, PayPal)
⏳ Base de datos de productos
⏳ Sistema de usuarios/login
⏳ Panel de administración
⏳ Wallet crypto funcional
⏳ Email marketing automatizado

---

🚀 **¡A por todas con FLIPPAY!**

La mejor perfumería online del mundo
Con IA + AR/VR + Crypto + 70% OFF
