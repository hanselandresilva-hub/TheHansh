# FLIPPAY - Perfumería Online Premium

La mejor perfumería online del mundo con IA, AR/VR y pagos con FLIP Token (criptomoneda propia).

## 🚀 Desplegar en Vercel (3 opciones)

### Opción 1: Deploy con un Click (MÁS RÁPIDO)

1. Ve a [vercel.com](https://vercel.com)
2. Click en "Sign Up" (gratis con GitHub, GitLab o email)
3. Click en "Add New..." → "Project"
4. Arrastra toda la carpeta o sube el repositorio de Git
5. Click "Deploy"
6. ¡Listo! Tu sitio estará en: `https://tu-proyecto.vercel.app`

### Opción 2: Deploy con Vercel CLI

```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Ir a la carpeta del proyecto
cd flippay-vercel

# 3. Login en Vercel
vercel login

# 4. Deploy
vercel

# 5. Deploy a producción
vercel --prod
```

### Opción 3: Deploy con GitHub

1. Sube este código a un repositorio de GitHub
2. Ve a vercel.com y conecta tu cuenta de GitHub
3. Importa el repositorio
4. Vercel detectará automáticamente que es un sitio estático
5. Click "Deploy"

## 🌐 Conectar tu Dominio Propio

### Paso 1: Compra tu dominio
- **Namecheap.com**: `flippay.xyz` - $0.99/año
- **Porkbun.com**: `flippay.store` - $0.99/año
- **Freenom.com**: `flippay.tk` - GRATIS

### Paso 2: Agregar dominio en Vercel
1. En tu dashboard de Vercel, ve a tu proyecto
2. Click en "Settings" → "Domains"
3. Agrega tu dominio: `flippay.xyz`
4. Vercel te dará los nameservers

### Paso 3: Configurar DNS
En tu proveedor de dominio, cambia los nameservers a:
```
ns1.vercel-dns.com
ns2.vercel-dns.com
```

### Paso 4: Esperar propagación
- Toma 5-30 minutos generalmente
- SSL gratis se activa automáticamente
- ¡Listo! Tu sitio estará en `https://flippay.xyz`

## 📁 Estructura del Proyecto

```
flippay-vercel/
├── index.html          # Página principal
├── vercel.json        # Configuración de Vercel
├── package.json       # Metadatos del proyecto
└── README.md          # Este archivo
```

## ✨ Características Implementadas

### 🎯 Neuromarketing & Conversión
- ✅ Countdown timers (urgencia)
- ✅ Social proof notifications en tiempo real
- ✅ Anchoring effect en precios
- ✅ Scarcity badges
- ✅ Trust signals prominentes
- ✅ Sticky cart bar

### 🛍️ E-commerce Premium
- ✅ 15,000+ fragancias
- ✅ Hasta 70% descuento
- ✅ Club Premium ($19.99/mes)
- ✅ 5 muestras gratis por pedido
- ✅ Envío gratis en compras +$50

### 🤖 Tecnología Avanzada
- ✅ IA Fragrance Finder (90% precisión)
- ✅ Vista AR/VR en productos
- ✅ Chatbot 24/7

### 🪙 Criptomoneda FLIP Token
- ✅ Pago con FLIP (ERC-20)
- ✅ 10% descuento extra con FLIP
- ✅ Gana 5% en tokens por compra
- ✅ Wallet connect (MetaMask, etc.)

### 🏆 Inspirado en los Mejores
- Amazon: Membresía, búsqueda, sticky cart
- Temu: Flash deals, descuentos masivos
- eBay: Trust signals, contador de vendidos
- Alibaba: Features bar, bulk benefits

## 🎨 Paleta de Colores FLIPPAY

```css
--navy-dark: #001F54    /* Azul oscuro principal */
--blue-main: #0074D9    /* Azul FLIPPAY */
--cyan-bright: #00D4FF  /* Cyan brillante */
--blue-light: #7EC8E3   /* Azul claro */
```

## 🔧 Personalización

### Cambiar colores
Edita las variables CSS en `index.html` (líneas 21-28):
```css
:root {
    --navy-dark: #TU_COLOR;
    --blue-main: #TU_COLOR;
    /* ... */
}
```

### Agregar productos
Busca `<div class="product-card">` en `index.html` y duplica el bloque.

### Modificar precios del Club
Busca `<div class="membership-price">` y actualiza los valores.

## 📊 Métricas Esperadas

Basado en estudios de neuromarketing 2025:
- Conversión esperada: 3.5-5.2%
- AOV (Average Order Value): $85-120
- Cart abandonment: <45% (vs 70% promedio)
- Return visitors: 40%+

## 🆘 Soporte

Si tienes problemas con el deploy:
1. Revisa la [documentación de Vercel](https://vercel.com/docs)
2. Verifica que `vercel.json` esté presente
3. Asegúrate de que `index.html` esté en la raíz

## 📈 Próximos Pasos

1. ✅ Deploy en Vercel
2. ⏳ Conectar dominio propio
3. ⏳ Configurar Google Analytics
4. ⏳ Integrar pasarela de pagos real
5. ⏳ Conectar wallet de crypto real
6. ⏳ Backend para productos dinámicos
7. ⏳ Base de datos de fragancias

## 📄 Licencia

MIT License - Libre para uso comercial

---

**Creado con ❤️ para FLIPPAY**
*La mejor perfumería online del mundo*
